﻿namespace PayPingdotNetCoreSample.Models.ExternalModels
{
    public class PPVerifyPayHookModel
    {
        public string RefId { get; set; }
        public string ClientRefId { get; set; }

    }
}