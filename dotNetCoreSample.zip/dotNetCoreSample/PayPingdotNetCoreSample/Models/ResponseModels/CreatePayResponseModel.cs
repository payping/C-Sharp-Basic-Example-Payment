﻿namespace PayPingdotNetCoreSample.Models.ResponseModels
{
    public class CreatePayResponseModel
    {
        public string Code { get; set; }
    }
}